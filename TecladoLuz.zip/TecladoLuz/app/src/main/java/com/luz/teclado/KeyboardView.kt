package com.luz.teclado

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator
import androidx.core.graphics.ColorUtils
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

private val ACCENTS = mapOf("a" to "á", "e" to "é", "i" to "í", "o" to "ó", "u" to "ú")

/** Teclado dibujado a mano en un Canvas: teclas + aros de luz + efecto de botón presionado. */
class KeyboardView(context: Context) : View(context) {

    interface Listener {
        fun onText(s: String)
        fun onBackspace()
        fun onEnter()
        fun onSpaceLong()
    }

    enum class Layer { LETTERS, SYM1, SYM2 }
    private enum class Style { NORMAL, GRAY, ENTER }

    private class Key(
        val id: String,
        val label: String?,
        val icon: Icon?,
        val weight: Float,
        val style: Style,
        val sup: String? = null,
        val pill: Boolean = false,
        val letter: Boolean = false,
        val low: Boolean = false,
        val small: Boolean = false
    ) {
        val rect = RectF()
        var pressed = false
        var pressT = 0L
        var releaseT = 0L
        var sFrom = 1f
        var tint = 0
    }

    private class Ring(val x: Float, val y: Float, val t: Long, val c: RingColors)

    private class Ptr(var key: Key?) {
        var alt: String? = null
        var fired = false
        var job: Runnable? = null
    }

    var listener: Listener? = null

    var shift = 0 // 0 apagado, 1 una vez, 2 bloqueado
        set(v) { field = v; invalidate() }
    var layer = Layer.LETTERS
        set(v) { field = v; resetTouch(); buildRows(); layoutKeys(); invalidate() }

    private var rows: List<List<Key>> = emptyList()
    private val rings = ArrayList<Ring>()
    private val ptrs = HashMap<Int, Ptr>()
    private val handler = Handler(Looper.getMainLooper())
    private val overshoot = OvershootInterpolator(2f)

    private var hu = 0f
    private var gap = 0f
    private var rowGap = 0f
    private val topH: Float get() = .12f * hu   // franja de arriba: da lugar al globito de la primera fila

    private var popKey: Key? = null
    private var popText = ""
    private var popT = 0L
    private var lastShift = 0L

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; color = Theme.INK }
    private val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; color = Theme.INK; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val supPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.RIGHT; color = Theme.SUP }
    private val popPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; color = Theme.INK }

    private val repeat = object : Runnable {
        override fun run() {
            listener?.onBackspace()
            handler.postDelayed(this, 50)
        }
    }

    init { buildRows() }

    // ---------------------------------------------------------------- layout

    private fun chars(s: String, letter: Boolean = false, sup: Boolean = false): List<Key> =
        s.mapIndexed { i, ch ->
            Key(ch.toString(), ch.toString(), null, 1f, Style.NORMAL,
                if (sup) ((i + 1) % 10).toString() else null, letter = letter)
        }

    private fun buildRows() {
        val del = Key("del", null, Icons.BACK, 1.62f, Style.GRAY)
        val letters = layer == Layer.LETTERS
        val bottom = listOf(
            Key(if (letters) "sym1" else "abc", if (letters) "?123" else "ABC", null, 1.6f, Style.GRAY, pill = true, small = true),
            Key(",", ",", null, 1f, Style.GRAY, low = true),
            Key(" ", null, null, 5.6f, Style.NORMAL),
            Key(".", ".", null, 1f, Style.GRAY, low = true),
            Key("enter", null, Icons.ENTER, 1.62f, Style.ENTER, pill = true)
        )
        rows = when (layer) {
            Layer.LETTERS -> listOf(
                chars("qwertyuiop", true, true),
                chars("asdfghjklñ", true),
                listOf(Key("shift", null, Icons.SHIFT, 1.6f, Style.GRAY)) + chars("zxcvbnm", true) + del,
                bottom
            )
            Layer.SYM1 -> listOf(
                chars("1234567890"),
                chars("@#\$_&-+()/"),
                listOf(Key("sym2", "=\\<", null, 1.6f, Style.GRAY, small = true)) + chars("*\"':;!?") + del,
                bottom
            )
            Layer.SYM2 -> listOf(
                chars("~`|•√π÷×¶∆"),
                chars("£¢€¥^°={}\\"),
                listOf(Key("sym1", "?123", null, 1.6f, Style.GRAY, small = true)) + chars("%©®™✓[]") + del,
                bottom
            )
        }
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        val screenH = resources.displayMetrics.heightPixels
        hu = min(w.toFloat(), .5f * screenH / .668f)
        textPaint.textSize = .06f * hu
        smallPaint.textSize = .04f * hu
        supPaint.textSize = .03f * hu
        popPaint.textSize = .08f * hu
        setMeasuredDimension(w, (.668f * hu).roundToInt())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        layoutKeys()
    }

    private fun layoutKeys() {
        val w = width.toFloat()
        if (w <= 0f) return
        val padX = .0135f * w
        gap = .0157f * w
        val kh = .111f * hu
        rowGap = .028f * hu
        rows.forEachIndexed { r, row ->
            val sum = row.sumOf { it.weight.toDouble() }.toFloat()
            val unit = (w - 2 * padX - gap * (row.size - 1)) / sum
            val y = topH + r * (kh + rowGap)
            var x = padX
            for (k in row) {
                val kw = unit * k.weight
                k.rect.set(x, y, x + kw, y + kh)
                x += kw + gap
            }
        }
    }

    // ---------------------------------------------------------------- dibujo

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        canvas.drawColor(Theme.PANEL)
        drawRings(canvas, now)
        for (row in rows) for (k in row) drawKey(canvas, k, now)
        drawPopup(canvas, now)
        if (animating(now)) postInvalidateOnAnimation()
    }

    private fun animating(now: Long): Boolean {
        if (rings.isNotEmpty() || ptrs.isNotEmpty()) return true
        if (popKey != null && now - popT < 100) return true
        for (row in rows) for (k in row) if (k.pressed || (k.releaseT > 0 && now - k.releaseT < 500)) return true
        return false
    }

    /** Efecto de botón: se hunde rápido al presionar y vuelve con un leve rebote. */
    private fun scaleOf(k: Key, now: Long): Float = when {
        k.pressed -> {
            val t = ((now - k.pressT) / 80f).coerceIn(0f, 1f)
            val e = 1f - (1f - t) * (1f - t)
            k.sFrom + (.9f - k.sFrom) * e
        }
        k.releaseT > 0 -> {
            val t = ((now - k.releaseT) / 380f).coerceIn(0f, 1f)
            k.sFrom + (1f - k.sFrom) * overshoot.getInterpolation(t)
        }
        else -> 1f
    }

    private fun tintAlpha(k: Key, now: Long): Float = when {
        k.pressed -> .62f
        k.releaseT > 0 -> (.62f * (1f - (now - k.releaseT) / 500f)).coerceAtLeast(0f)
        else -> 0f
    }

    /** Aro de luz: arranca como un disco y se abre en un aro ancho de bordes difusos. */
    private fun drawRings(c: Canvas, now: Long) {
        rings.removeAll { now - it.t >= 1250 }
        if (rings.isEmpty()) return
        val m = 1f / (1f + .22f * (rings.size - 1))
        val u = hu / 440f
        val maxR = hu * .46f
        for (r in rings) {
            val k = (now - r.t) / 1250f
            val big = 1f - (1f - k).pow(2.2f)
            val rad = 30f * u + big * (maxR - 30f * u)
            val sm = min(1f, .45f + k * 2.5f)
            val rg = rad * 1.3f
            val a = (1f - k).pow(1.4f) * .9f * m
            val hue = r.c.h0 + (r.c.h1 - r.c.h0) * min(1f, k * 1.1f)
            val base = ColorUtils.HSLToColor(floatArrayOf(((hue % 360f) + 360f) % 360f, r.c.s, r.c.l - k * .06f))
            fun col(al: Float) = ColorUtils.setAlphaComponent(base, (al.coerceIn(0f, 1f) * 255).roundToInt())
            val pk = a * (.3f + .7f * sm)
            val i0 = .05f + .2f * sm
            val colors = intArrayOf(col(a * (1f - sm * .9f)), col(0f), col(pk * .45f), col(pk), col(pk * .45f), col(0f))
            val pos = floatArrayOf(0f, i0, i0 + (.6f - i0) / 2f, .6f, .8f, 1f)
            ringPaint.shader = RadialGradient(r.x, r.y, rg, colors, pos, Shader.TileMode.CLAMP)
            c.drawCircle(r.x, r.y, rg, ringPaint)
        }
        ringPaint.shader = null
    }

    private fun drawIcon(c: Canvas, icon: Icon, cx: Float, cy: Float, size: Float, color: Int, filled: Boolean) {
        c.save()
        c.translate(cx, cy)
        val sc = size / 24f
        c.scale(sc, sc)
        c.translate(-12f, -12f)
        strokeP.color = color
        strokeP.strokeWidth = 1.8f
        fillP.color = color
        for ((path, f) in icon.paths) {
            if (f) c.drawPath(path, fillP)
            else {
                if (filled) c.drawPath(path, fillP)
                c.drawPath(path, strokeP)
            }
        }
        c.restore()
    }

    private fun shape(c: Canvas, k: Key) {
        if (k.pill) c.drawOval(k.rect, fill)
        else c.drawRoundRect(k.rect, .016f * hu, .016f * hu, fill)
    }

    private fun display(k: Key): String {
        val l = k.label ?: return ""
        return if (k.letter && shift > 0) l.uppercase() else l
    }

    private fun drawKey(c: Canvas, k: Key, now: Long) {
        val s = scaleOf(k, now)
        c.save()
        c.scale(s, s, k.rect.centerX(), k.rect.centerY())
        fill.color = when (k.style) {
            Style.NORMAL -> Theme.KEY
            Style.GRAY -> Theme.GRAY
            Style.ENTER -> Theme.ENTER
        }
        shape(c, k)
        val ta = tintAlpha(k, now)
        if (ta > 0f) {
            fill.color = ColorUtils.setAlphaComponent(k.tint, (ta * 255).roundToInt())
            shape(c, k)
        }
        val cx = k.rect.centerX()
        val cy = k.rect.centerY()
        val icon = k.icon
        val label = k.label
        if (icon != null) {
            val sz = .062f * hu
            if (k.id == "shift") {
                drawIcon(c, icon, cx, cy - .004f * hu, sz, Theme.INK, shift > 0)
                if (shift == 2) {
                    strokeP.color = Theme.INK
                    strokeP.strokeWidth = 1.8f * sz / 24f
                    val y = cy + sz * .46f
                    c.drawLine(cx - sz * .13f, y, cx + sz * .13f, y, strokeP)
                }
            } else drawIcon(c, icon, cx, cy, sz, Theme.INK, false)
        } else if (label != null) {
            val p = if (k.small) smallPaint else textPaint
            val y = cy - (p.descent() + p.ascent()) / 2f + (if (k.low) .012f * hu else 0f)
            c.drawText(display(k), cx, y, p)
        }
        k.sup?.let { c.drawText(it, k.rect.right - .014f * hu, k.rect.top + .012f * hu + supPaint.textSize * .9f, supPaint) }
        c.restore()
    }

    private fun drawPopup(c: Canvas, now: Long) {
        val k = popKey ?: return
        val pw = .1f * hu
        val ph = .13f * hu
        val l = (k.rect.centerX() - pw / 2f).coerceIn(2f, width - pw - 2f)
        val top = k.rect.top - ph + k.rect.height() * .12f
        val r = RectF(l, top, l + pw, top + ph)
        val sc = .82f + .18f * ((now - popT) / 90f).coerceIn(0f, 1f)
        c.save()
        c.scale(sc, sc, r.centerX(), r.bottom)
        fill.color = Theme.GRAY
        c.drawRoundRect(r, .02f * hu, .02f * hu, fill)
        c.drawText(popText, r.centerX(), r.centerY() - (popPaint.descent() + popPaint.ascent()) / 2f, popPaint)
        c.restore()
    }

    // ---------------------------------------------------------------- toque

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                down(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i), e.getY(i))
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val i = e.actionIndex
                up(e.getPointerId(i), false)
            }
            MotionEvent.ACTION_CANCEL -> ptrs.keys.toList().forEach { up(it, true) }
        }
        return true
    }

    private fun keyAt(x: Float, y: Float): Key? {
        for (row in rows) {
            val r0 = row[0].rect
            if (y >= r0.top - rowGap / 2f && y <= r0.bottom + rowGap / 2f) {
                for (k in row) if (x < k.rect.right + gap / 2f) return k
                return row.last()
            }
        }
        return null
    }

    private fun haptic() { performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }

    private fun accentOf(k: Key): String? = if (k.letter) k.label?.let { ACCENTS[it] } else null

    private fun down(id: Int, x: Float, y: Float) {
        val k = keyAt(x, y) ?: return
        val p = Ptr(k)
        ptrs[id] = p
        press(k, p, x, y, true)
    }

    private fun press(k: Key, p: Ptr, x: Float, y: Float, ring: Boolean) {
        val now = SystemClock.uptimeMillis()
        k.sFrom = scaleOf(k, now)
        k.pressed = true
        k.pressT = now
        k.releaseT = 0L
        val col = RingColors.rainbow()
        k.tint = ColorUtils.HSLToColor(floatArrayOf(((col.tint % 360f) + 360f) % 360f, .8f, .66f))
        if (ring) {
            rings.add(Ring(x, y, now, col))
            if (rings.size > 10) rings.removeAt(0)
        }
        haptic()
        val lbl = k.label
        if (k.icon == null && lbl != null && (k.letter || lbl.length == 1)) {
            popKey = k; popText = display(k); popT = now
        }
        when {
            k.id == "del" -> { listener?.onBackspace(); handler.postDelayed(repeat, 400) }
            k.id == " " || accentOf(k) != null -> {
                val job = Runnable { onLong(p, k) }
                p.job = job
                handler.postDelayed(job, 350)
            }
        }
        invalidate()
    }

    private fun onLong(p: Ptr, k: Key) {
        if (k.id == " ") { p.fired = true; haptic(); listener?.onSpaceLong(); return }
        val alt = accentOf(k) ?: return
        p.fired = true
        p.alt = if (shift > 0) alt.uppercase() else alt
        popText = p.alt ?: ""
        popT = SystemClock.uptimeMillis()
        haptic()
        invalidate()
    }

    private fun cancelJob(p: Ptr) {
        p.job?.let { handler.removeCallbacks(it) }
        p.job = null
    }

    private fun release(k: Key?) {
        if (k == null || !k.pressed) return
        val now = SystemClock.uptimeMillis()
        k.sFrom = scaleOf(k, now)
        k.pressed = false
        k.releaseT = now
        if (k.id == "del") handler.removeCallbacks(repeat)
        if (k === popKey) popKey = null
        invalidate()
    }

    private fun move(id: Int, x: Float, y: Float) {
        val p = ptrs[id] ?: return
        val nk = keyAt(x, y)
        if (nk === p.key) return
        cancelJob(p)
        release(p.key)
        p.key = nk
        p.alt = null
        p.fired = false
        if (nk != null) press(nk, p, x, y, false)
    }

    private fun up(id: Int, cancel: Boolean) {
        val p = ptrs.remove(id) ?: return
        cancelJob(p)
        val k = p.key ?: return
        release(k)
        if (!cancel) commit(k, p)
    }

    private fun commit(k: Key, p: Ptr) {
        when (k.id) {
            "shift" -> {
                val now = SystemClock.uptimeMillis()
                shift = when {
                    shift == 2 -> 0
                    shift == 1 && now - lastShift < 350 -> 2
                    shift == 1 -> 0
                    else -> 1
                }
                lastShift = now
            }
            "sym1" -> layer = Layer.SYM1
            "sym2" -> layer = Layer.SYM2
            "abc" -> layer = Layer.LETTERS
            "enter" -> listener?.onEnter()
            "del" -> {}
            " " -> if (!p.fired) listener?.onText(" ")
            else -> {
                var t = p.alt ?: k.label ?: return
                if (k.letter && shift > 0 && p.alt == null) t = t.uppercase()
                listener?.onText(t)
                if (shift == 1 && k.letter) shift = 0
            }
        }
    }

    private fun resetTouch() {
        ptrs.values.forEach { cancelJob(it) }
        ptrs.clear()
        handler.removeCallbacks(repeat)
        popKey = null
    }

    /** El IME avisa si corresponde mayúscula automática (inicio de oración). */
    fun setAutoShift(on: Boolean) {
        if (shift != 2) shift = if (on) 1 else 0
    }

    override fun onDetachedFromWindow() {
        resetTouch()
        super.onDetachedFromWindow()
    }
}

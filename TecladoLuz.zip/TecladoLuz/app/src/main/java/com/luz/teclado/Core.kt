package com.luz.teclado

import android.graphics.Color
import android.graphics.Path
import androidx.core.graphics.PathParser
import kotlin.random.Random

/** Colores del tema oscuro. */
object Theme {
    val PANEL = Color.parseColor("#0C0019")
    val KEY = Color.parseColor("#1B003A")
    val GRAY = Color.parseColor("#340856")
    val ENTER = Color.parseColor("#340856")
    val INK = Color.parseColor("#F3EEFF")
    val SUP = Color.parseColor("#9A8BB8")
}

/** Ícono vectorial: lista de (pathData SVG 24x24, relleno?). */
class Icon(private vararg val parts: Pair<String, Boolean>) {
    val paths: List<Pair<Path, Boolean>> by lazy {
        parts.map { PathParser.createPathFromPathData(it.first) to it.second }
    }
}

object Icons {
    val SHIFT = Icon("M12 4l8 9h-5v4H9v-4H4z" to false)
    val BACK = Icon(
        "M8.5 5H20a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H8.5L2.5 12z" to false,
        "M12.5 9.5l5 5M17.5 9.5l-5 5" to false
    )
    val ENTER = Icon("M20 6v6a2 2 0 0 1-2 2H5M9 9.5L4.5 14 9 18.5" to false)
}

/** Colores de un aro de luz: el matiz va de h0 a h1 mientras se expande (arcoíris). */
class RingColors(val h0: Float, val h1: Float, val s: Float, val l: Float, val tint: Float) {
    companion object {
        fun rainbow(): RingColors {
            val h = Random.nextFloat() * 360f
            return RingColors(h, h + 140f, .95f, .58f, h)
        }
    }
}

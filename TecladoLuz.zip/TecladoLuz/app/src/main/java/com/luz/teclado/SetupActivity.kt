package com.luz.teclado

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/** Pantalla de ayuda: activar el teclado, elegirlo y probarlo. */
class SetupActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Theme.PANEL)
            setPadding(pad, pad, pad, pad)
        }

        fun label(t: String, size: Float, color: Int = Theme.INK) = TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
            setPadding(0, (12 * d).toInt(), 0, (6 * d).toInt())
        }

        root.addView(label("Teclado Luz", 26f))
        status = label("", 14f, Theme.SUP)
        root.addView(status)

        root.addView(label("1. Activalo en los ajustes del teléfono", 16f))
        root.addView(Button(this).apply {
            text = "Abrir ajustes de teclados"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })

        root.addView(label("2. Elegilo como teclado actual", 16f))
        root.addView(Button(this).apply {
            text = "Elegir teclado"
            setOnClickListener {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        })

        root.addView(label("3. Probalo acá", 16f))
        root.addView(EditText(this).apply {
            hint = "Escribí algo…"
            setTextColor(Theme.INK)
            setHintTextColor(Theme.SUP)
            minLines = 3
        })

        root.addView(label(
            "Tip: mantené apretada la barra espaciadora para cambiar a otro teclado.",
            13f, Theme.SUP
        ))

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(pad, b.top + pad, pad, b.bottom + pad)
            insets
        }
        setContentView(ScrollView(this).apply {
            setBackgroundColor(Theme.PANEL)
            isFillViewport = true
            addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        val enabled = imm.enabledInputMethodList.any { it.packageName == packageName }
        status.text = if (enabled) "✓ Teclado activado" else "Todavía no está activado"
        status.setTextColor(if (enabled) Color.parseColor("#7CE0A3") else Theme.SUP)
    }
}

package com.luz.teclado

import android.inputmethodservice.InputMethodService
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout

class LuzIME : InputMethodService(), KeyboardView.Listener {

    private lateinit var kb: KeyboardView

    override fun onEvaluateFullscreenMode() = false

    override fun onCreateInputView(): View {
        val root = FrameLayout(this)
        root.setBackgroundColor(Theme.PANEL)
        kb = KeyboardView(this)
        kb.listener = this
        root.addView(
            kb,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        return root
    }

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!::kb.isInitialized) return
        val cls = info.inputType and InputType.TYPE_MASK_CLASS
        kb.layer = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE ||
            cls == InputType.TYPE_CLASS_DATETIME
        ) KeyboardView.Layer.SYM1 else KeyboardView.Layer.LETTERS
        updateShift()
    }

    /** Mayúscula automática al empezar una oración, según lo que pida el campo. */
    private fun updateShift() {
        val info = currentInputEditorInfo ?: return
        val ic = currentInputConnection ?: return
        val isText = (info.inputType and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_TEXT
        kb.setAutoShift(isText && ic.getCursorCapsMode(info.inputType) != 0)
    }

    override fun onText(s: String) {
        currentInputConnection?.commitText(s, 1)
        updateShift()
    }

    override fun onBackspace() {
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        updateShift()
    }

    override fun onEnter() {
        val info = currentInputEditorInfo ?: return
        val action = info.imeOptions and EditorInfo.IME_MASK_ACTION
        val noAction = (info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0 ||
            action == EditorInfo.IME_ACTION_NONE || action == EditorInfo.IME_ACTION_UNSPECIFIED
        if (noAction) sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        else currentInputConnection?.performEditorAction(action)
        updateShift()
    }

    /** Mantener apretada la barra espaciadora abre el selector de teclados. */
    override fun onSpaceLong() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
    }
}

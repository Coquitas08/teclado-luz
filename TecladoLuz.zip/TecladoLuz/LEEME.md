# Teclado Luz

Teclado de Android (IME) en modo oscuro, con aro de luz arcoíris y teclas que se hunden al presionarlas.
Funciones: letras, mayúsculas (un toque = una, doble toque = bloqueo, automática al empezar oración),
borrar (se repite al mantener), números y símbolos, coma, punto, espacio y enviar/enter.
Extras mínimos: tecla ñ y tildes (mantené una vocal). Mantené la barra espaciadora para cambiar de teclado.

## Generar el APK
1. Abrí la carpeta `TecladoLuz` con Android Studio (File > Open) y esperá a que termine el Sync.
2. Menú Build > Build Bundle(s) / APK(s) > Build APK(s).
3. Cuando termine, tocá "locate" en el aviso. El archivo es app/build/outputs/apk/debug/app-debug.apk
4. Pasalo al celular (cable, Drive, WhatsApp), abrilo y permití instalar de orígenes desconocidos.
5. Abrí "Teclado Luz": 1) abrí los ajustes de teclados y activalo, 2) elegilo, 3) probalo en el campo de texto.
